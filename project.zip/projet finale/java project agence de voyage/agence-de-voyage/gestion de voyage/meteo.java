import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;
public class meteo {
	protected Date date;
	protected String Description;

	meteo() throws SQLException{ 
	try {
		date = new Date();
	    Scanner LireClavier = new Scanner(System.in);
	    System.out.println("veuillez saisir la date de d�part"); 
	    System.out.println("donner la Date: ");
	    date.saisir_date();
	    System.out.println(" donner la Description");
	    Description = LireClavier.next(); 
        ///***requette de saisie
    	String login = null;
		String passwd = null;
		String url = null;
		// Etape 2 : recuperation de la connexion
		Connection cn = DriverManager.getConnection(url, login, passwd);

		// Etape 3 : Creation d'un statement
		Statement st = (Statement) cn.createStatement();
		
		// Etape 4 : execution requete
		Object rs = ((java.sql.Statement) st).executeQuery("INSERT INTO 'avion' Values(");
		// Si recup donnees alors etapes 5 (parcours Resultset)
      
	} catch (InputMismatchException LE) {
	    System.out.println("entree detectee est invalide");
	  
	}
	}
}
